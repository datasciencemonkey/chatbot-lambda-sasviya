settings={
    "host" : "10.249.5.39",
    "portnum" : 8777 
}